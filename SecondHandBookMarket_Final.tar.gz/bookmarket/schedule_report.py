import subprocess
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")

print("Sunday 7 PM Report Scheduler Started")

while True:
    now = datetime.now(IST)
    days_ahead = (6 - now.weekday()) % 7

    next_run = (now + timedelta(days=days_ahead)).replace(
        hour=19, minute=0, second=0, microsecond=0
    )

    if next_run <= now:
        next_run += timedelta(days=7)

    print("Next report:", next_run.strftime("%d-%m-%Y %I:%M %p"))
    time.sleep((next_run - now).total_seconds())

    subprocess.run(["/bin/bash", "generate_report.sh"], check=True)
    print("Sunday report generated successfully!")
